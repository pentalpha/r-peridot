# ClusterProfiler
Author: Guangchuang Yu [aut, cre], Li-Gen Wang [ctb], Giovanni Dall'Olio [ctb] (formula interface of compareCluster)

Maintainer: Guangchuang Yu <guangchuangyu at gmail.com>

# edgeR
Author: Yunshun Chen <yuchen at wehi.edu.au>, Aaron Lun <alun at wehi.edu.au>, Davis McCarthy <dmccarthy at wehi.edu.au>, Xiaobei Zhou <xiaobei.zhou at uzh.ch>, Mark Robinson <mark.robinson at imls.uzh.ch>, Gordon Smyth <smyth at wehi.edu.au>

Maintainer: Yunshun Chen <yuchen at wehi.edu.au>, Aaron Lun <alun at wehi.edu.au>, Mark Robinson <mark.robinson at imls.uzh.ch>, Davis McCarthy <dmccarthy at wehi.edu.au>, Gordon Smyth <smyth at wehi.edu.au>

# DESeq
Author: Simon Anders, EMBL Heidelberg <sanders at fs.tum.de>.

Maintainer: Simon Anders <sanders at fs.tum.de>.


# DESeq2
Author: Michael Love, Simon Anders, Wolfgang Huber.

Maintainer: Michael Love <michaelisaiahlove at gmail.com>.


# EBSeq
Author: Ning Leng, Christina Kendziorski.

Maintainer: Ning Leng <lengning1 at gmail.com>.

# sSeq
Author: Danni Yu <dyu at purdue.edu>, Wolfgang Huber <whuber at embl.de> and Olga Vitek <ovitek at purdue.edu>

Maintainer: Danni Yu <dyu at purdue.edu>